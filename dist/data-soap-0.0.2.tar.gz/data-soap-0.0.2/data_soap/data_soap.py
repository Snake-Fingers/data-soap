def soap():
    """Pulls trailing and leading character
    """
    pass

def show_diff():
    """Shows both the original and cleaned dataframes.
    """
    pass 